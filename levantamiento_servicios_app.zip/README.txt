
# Levantamiento de Servicios Básicos

## Cómo generar tu APK con Codemagic

1. Ve a https://codemagic.io y regístrate con tu cuenta de GitHub, Google o email.
2. Crea una nueva app y elige "Upload project as zip".
3. Sube el archivo ZIP de este proyecto.
4. Selecciona un workflow predeterminado para Android (puedes usar el build.yaml que Codemagic genera).
5. Presiona "Start build".
6. Al finalizar, descarga tu APK desde la sección de Artifacts.

No necesitas instalar Android Studio para compilar.

Usuarios válidos en la app:
- admin / 1234
- user1 / 5678
